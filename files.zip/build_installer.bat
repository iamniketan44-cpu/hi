@echo off
title FastLauncher - Installer Builder
echo ============================================
echo   FastLauncher_Setup.exe banane ka script
echo ============================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo Python nahi mila. Pehle python.org se Python install karo.
    pause
    exit /b 1
)
if not exist logo.ico (
    echo logo.ico nahi mili. Isse fast_launcher.py ke saath ek hi folder me rakho.
    pause
    exit /b 1
)

echo [1/3] Libraries install ho rahi hain...
py -m pip install --upgrade pip
py -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (
    echo Install fail hua. Internet check karo.
    pause
    exit /b 1
)

echo.
echo [2/3] FastLauncher.exe ban raha hai (1-3 minute)...
py -m PyInstaller --onefile --noconsole --clean --name FastLauncher --icon logo.ico --collect-all minecraft_launcher_lib fast_launcher.py
if errorlevel 1 (
    echo Build fail hua. Upar ka error dekho.
    pause
    exit /b 1
)

echo.
echo [3/3] Installer ban raha hai...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" goto build
set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" goto build
set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" goto build

echo Inno Setup nahi mila. Ise ek baar install karo:
echo     winget install JRSoftware.InnoSetup
echo Phir ye script dobara chalao.
echo Tab tak portable file yahan hai: dist\FastLauncher.exe
pause
exit /b 0

:build
"%ISCC%" setup.iss
if errorlevel 1 (
    echo Installer build fail hua.
    pause
    exit /b 1
)
echo.
echo Done! Sabko ye file bhejo:  installer\FastLauncher_Setup.exe
pause
