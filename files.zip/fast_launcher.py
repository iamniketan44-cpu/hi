"""
FastLauncher - Minecraft launcher for low-end PCs (i3 8th gen, iGPU, 8 GB RAM)

Kya karta hai:
  1. Fabric install karta hai
  2. Modrinth se performance mods download karta hai
     (Sodium, Lithium, FerriteCore, EntityCulling, ModernFix, ImmediatelyFast)
  3. options.txt me low-end friendly settings (unlimited FPS, vsync off, render distance 6)
  4. Optimized JVM flags + 3 GB RAM ke saath game chalata hai

Setup (ek baar):
    pip install minecraft-launcher-lib
Run:
    python fast_launcher.py
"""

import io
import json
import os
import subprocess
import sys
import threading
import urllib.parse
import urllib.request
import uuid
import re
import shutil
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import minecraft_launcher_lib as mll

try:  # mod ke logo dikhane ke liye (optional)
    from PIL import Image, ImageTk
    HAVE_PIL = True
except Exception:
    HAVE_PIL = False

# ---------------- Config ----------------
APP_DIR = os.path.join(os.path.expanduser("~"), ".fastlauncher")
MC_DIR = os.path.join(APP_DIR, "minecraft")
CONFIG_FILE = os.path.join(APP_DIR, "config.json")

DEFAULT_VERSION = "1.20.1"
DEFAULT_RAM_GB = 3  # 8 GB PC par 3 GB best hai; zyada doge to lag badhega

MODS = [
    "fabric-api",
    "sodium",          # rendering ka sabse bada boost
    "lithium",         # game logic optimize
    "ferrite-core",    # RAM usage kam
    "entityculling",   # jo dikh nahi raha usse render nahi karta
    "modernfix",       # load time + memory
    "immediatelyfast", # UI/entity rendering fast
    "modmenu",         # in-game mods menu (Right Shift se kholne ke liye key set karo)
    "modern-keystrokes",  # keystrokes + CPS + FPS counter (Lunar jaisa HUD)
]

# Aikar-style G1GC flags: lag spikes / stutter kam
JVM_FLAGS = [
    "-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled", "-XX:MaxGCPauseMillis=200",
    "-XX:+UnlockExperimentalVMOptions", "-XX:+DisableExplicitGC",
    "-XX:+AlwaysPreTouch", "-XX:G1NewSizePercent=30", "-XX:G1MaxNewSizePercent=40",
    "-XX:G1HeapRegionSize=8M", "-XX:G1ReservePercent=20",
    "-XX:G1HeapWastePercent=5", "-XX:G1MixedGCCountTarget=4",
    "-XX:InitiatingHeapOccupancyPercent=15", "-XX:G1MixedGCLiveThresholdPercent=90",
    "-XX:G1RSetUpdatingPauseTimePercent=5", "-XX:SurvivorRatio=32",
    "-XX:+PerfDisableSharedMem", "-XX:MaxTenuringThreshold=1",
]

LOW_END_OPTIONS = {
    "maxFps": "260",              # 260 = unlimited
    "enableVsync": "false",
    "renderDistance": "6",
    "simulationDistance": "5",
    "particles": "2",             # minimal
    "graphicsMode": "0",          # fast
    "entityDistanceScaling": "0.75",
    "biomeBlendRadius": "1",
    "mipmapLevels": "0",
    "entityShadows": "false",
    "ao": "false",
}


def load_config():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg):
    os.makedirs(APP_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


def offline_uuid(name):
    return str(uuid.uuid3(uuid.NAMESPACE_OID, "OfflinePlayer:" + name))


def http_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "FastLauncher/1.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())


def download_mod(slug, mc_version, mods_dir, log):
    q = urllib.parse.urlencode({
        "game_versions": json.dumps([mc_version]),
        "loaders": json.dumps(["fabric"]),
    })
    versions = http_json(f"https://api.modrinth.com/v2/project/{slug}/version?{q}")
    if not versions:
        log(f"  [skip] {slug}: {mc_version} ke liye version nahi mila")
        return
    files = versions[0]["files"]
    f = next((x for x in files if x.get("primary")), files[0])
    path = os.path.join(mods_dir, f["filename"])
    if os.path.exists(path):
        log(f"  [ok] {slug} pehle se hai")
        return
    req = urllib.request.Request(f["url"], headers={"User-Agent": "FastLauncher/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r, open(path, "wb") as out:
        out.write(r.read())
    log(f"  [done] {f['filename']}")


def search_mods(query, mc_version, offset=0, limit=30):
    """Modrinth par Fabric mods search (selected Minecraft version ke liye)."""
    facets = json.dumps([["project_type:mod"], ["categories:fabric"],
                         [f"versions:{mc_version}"]])
    q = urllib.parse.urlencode({"query": query, "facets": facets, "limit": limit,
                                "offset": offset, "index": "downloads" if not query else "relevance"})
    return http_json(f"https://api.modrinth.com/v2/search?{q}").get("hits", [])


def install_mod(project, mc_version, mods_dir, log, seen=None):
    """Mod + uske required dependencies download karta hai."""
    seen = seen if seen is not None else set()
    if project in seen:
        return
    seen.add(project)
    q = urllib.parse.urlencode({
        "game_versions": json.dumps([mc_version]),
        "loaders": json.dumps(["fabric"]),
    })
    versions = http_json(f"https://api.modrinth.com/v2/project/{project}/version?{q}")
    if not versions:
        log(f"{project}: {mc_version} ke liye version nahi mila")
        return
    v = versions[0]
    for dep in v.get("dependencies", []):
        if dep.get("dependency_type") == "required" and dep.get("project_id"):
            install_mod(dep["project_id"], mc_version, mods_dir, log, seen)
    files = v["files"]
    f = next((x for x in files if x.get("primary")), files[0])
    path = os.path.join(mods_dir, f["filename"])
    if os.path.exists(path):
        log(f"{f['filename']} pehle se hai")
        return
    req = urllib.request.Request(f["url"], headers={"User-Agent": "FastLauncher/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r, open(path, "wb") as out:
        out.write(r.read())
    log(f"Installed: {f['filename']}")


def apply_low_end_options():
    """options.txt sirf pehli baar banata hai; baad me user ki settings ko nahi todta."""
    path = os.path.join(MC_DIR, "options.txt")
    if os.path.exists(path):
        return
    os.makedirs(MC_DIR, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for k, v in LOW_END_OPTIONS.items():
            f.write(f"{k}:{v}\n")


def find_fabric_id(mc_version):
    for v in mll.utils.get_installed_versions(MC_DIR):
        if v["id"].startswith("fabric-loader") and v["id"].endswith(mc_version):
            return v["id"]
    return None


# ---------------- Logo ----------------
LOGO_B64 = "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAALrklEQVR4nM1be2xcV5n/feece+feGc/4MU6Ckxg3oXHcB1XZBuhuE0K33ZCqPEUdBNoVSPyxQttFQspqEQmZTNukSC1FCBWxK1jQCi2SvUCq7bYpj0JpUkpL1JImLklTSOskbhzH7xnPzD3nfPxxZxw72Hl4rq/7s+4fM+N77/l+53ud73yHcAXIcU78GhDLe/u4d1uvuZJ7lgq1sX4QsHnK28v9P136aTnRvfsG6qVtZuZ3G+8cbMRYvUONFo2NjXirb3jy0D//Z1D7Lsc5AQCXImJeArq5R9YEv6sv1ylc+gQ8sYmk7CSBVubLkBc3CABjhLU9gcA+x4Xyvidu3PsyMFuWuW77K9Ru+NBL/36Nak7uEin3006z7wWDBZROjiIYLABEAPPiCXQ1IAIsQ2V9eB1NcNsaEIyXrC3qn5rR4n37b3rw8Hwk/BUBm3+VU8/cntdbXvnKJ93W5H+42VR25Bd/wvl9x/Tk7wcoGCwSl83ba/YBAAxyJausz6mb38EtH1mnsnevg54ol/RY+UtPdua/MxcJswSpCb+1b+eXvFWZRypDRfQ/eFCPPH5CclmT8ByQIwDxNpQfACyDtYUtaZAgZG7v0O07NqrU+lZMvTH88JNdD/xbTcbaLdOSdPf0yN5t28yWozs/nlyd+enUG6Pm9S88ScUjQ0I1eyAisOV41D605wXfS9UJ0qNluKvTvPbRD5nGW9tV8fjQF/ffuOdbMzWBgNBb5rGbt762e5X05REOOH38nx7D1Kuh8BxcNppEByKwsdNC1PUoJWAmK3CWJbnzhx817soMVc5Pvu+p6/e+lOMc5SlvBQD04QYCERPsA4kV6cb+PQds8ZVzSyO8NlC+Ezq2OsHaQja4qJyZpDd2/Yak70jhqEcwQ79EjnOil7aZuw/n1sqM95mRp/9kRx4/IVVLzMILgp0K4HU04trP3wpbDCLxNawtVLOHiQOn5Lkf91l3RcPmrUd2bMxT3nZzjxSPHxqQAGBcu81tTTnnf3LMcsUQRTADVwMCYLXBmp2bsezaldDlAJGNgRkkCcP7jlvhKKaE+EcAGMRREmtvGbEAIDz5gWCwgMkXB0h4Emzjm31SAnqkhNbPvhttW7vgjBmwiO75bBnkKRSPDonSiWESnvo7AHgGeSN6qdd093RLclVn6eQognNFIkcu3AtfJUgSzHgZ6fevwop7b0GyIKGUA0aEqSZXHeJYmYqvnYdwVMcdP/+XLKjK80CyNUOCssFgAVw2FFucJ4ADC9mYQPuujSAlkCb/ciuUhb2KQn8QvFUAlMioxmQrAESoaAsYlCCYQoBV22+F15WFKBpkEklYtqCYlhpLRkDN7rP3dCF7TxcqI0UkXR++SMDGZX9YIgLCma/A78pi1fZbYQsaTEBa+VAkwTEusuIngKpeWQm079oE2ZgABwYgIKNSsQ8ndgJICpixMtru3YD0+1fCjJcBSZAk0KD8qvrHl4PESgBJgh4toWnLGiz/3E3QIyWQErBs4YsEkjJRdYDxIT4CBMGWDNyVaazecRtYh4kWgWDBSEsfDqnQ/cXIQKwawNpi9Y7b4K5Mw5bMrFw/48Rv/0BMBNRC3vLP3YSmLWugR0sgWROeISCQVj54CQqNi07AhVR3Jdru3QAzVgbJC6+1zPCki6TwYBHj6rOKxSVgVqq7CaREWFWi2s8EC4sG6cEREhYMriVBgi59RQQV2ZPmAAmCHq+gY8dt8Luy0MNTIDWbcwaQdTJwSMGShSMUhAVsIYBNBLBmDq1ghvCdSMa4aASQEtDDU8h2X4fsPV3TIW8mGAxJAkPBGCZMEZYZ8qzExHs8rP/vj0EqObsGSQBrhmxMYPAHhzH2y5OQKSfUqgViUQi4ONU1hWDeGh+BMFQZv6D6JYZoVmj+YMfs+isB0BYyk8DE86cx8dvTEL6qO22OnoA5Ul0zUZnh9ecYBAnMcAxgzdATldnFYcsgRyA4OYaT238JWwpCM6hj9oFFcIJzpbqXEh4IheQZf9OlbUGg6gUiyKSLMw89j/Kb45Apt27hgYgJmC/VrRe1wuZQbx+G/+81qKbEdCZZL6IjYJ5Ut16wZcgGF8Wj53D64d9BNtTn9C5GpBpwqVR3YQ8MTYEDg/77DsAWKqFGRVguiISAS6e6CwebMIkaePQQCr8fgEwnwCbaYkndUaBm9w0b2vCOL/wN9HAp9OSXGWjo+OcniQ1DNXkY/dmfMfj9w5DNXmRmNRP1EUCArRgkVqex5pE74bQmYYrB5WefCLakwWUz99KXGSIhURmYxKm9ByNxpPOhTg0IGxNko4ez3/sDbLECEpcZrCDYQgWNf38NmraunTNJYgaEK3HqwedQOT0B1bQ4sw/USwAzyJUonRhG8fDgFTk9kgQ9VkZ6Y/ucDo21hWrxMfhff8Do/tehmv1FEx6IIhNkgFwJ5V3Bo6pb396yJBpuaYOd0rNmnw1Dpl0UXj6LgW+9GDq9Rd6ii8a4OBz85S5Yhi1qeGub4LalwJUZPoABUgQ7pdF/37OwZQNStOhbdPFWhQngwCD17uWgxOyFDNtwL//MN15A8fAgZIMbecibC/HWBKvmktrQFtp1NQyytlBNHkaeeB3n/ufoojq9ixEfAdXZd5Yl4a9rAZdNuP9vGcJXKL85jlNfew7Ck7F238VGABGBSwZ+Vyuc5cnp3SAgzCRP7TmI4GwBwr2oCLLIiFEDwgiQes8KkBPOMmsL2RTmEGNPnwxVPwa7n4nYCGDLEJ5C6qbl4exbhswkMPnCGbz17UOQmQR4rvrfIiMeAgjgioG7Kg2/syVsZHQlzEQF/fcfABsO84El6LyNZ2NEEGxZw+/KQjV74IqFTDk48/DzmHp1qO7CZj2Izwcw0LChDcyAbExgeN9xDPW8GhISU8ibC7EQwJYhUg6SN7SClED5z6M4/dBvIZIOeOlkB1AlQKsKAUyLEn4EwZYNEu0ZJNY0g0sa/Q8cRDBcgnBF/C331fexCDveBQAkEqvH2WBUZZMgV3CUgyICuGyQvK4ViY4MBh49hIkD/VCN0Vd3LgXmcCWqWpNgYwt6VI8A1VbZZ27Pa9b6hHdNE1SLzxzYSPfo2TAym9+J8Wf7cfa7L0PGmOpOwzBE2mV/XQtsYPqfvuObgwAw3SrLJXvQbUsjdfMKrvXbRwEOLNwVSbir03hz5zOAiKQP+qpAIqxA+etbbLIzyyjrF0DEmzmnxIdvaTMAIAz1BqNT3PKxTkGCotHNavjz1rXg3A+PhCEvuQQhr1pZbr57HUEQYcr8CACW4wYmAOju6Za923rNXcd2Pea1N3702Gcf02O/OKkiCVHVjM9MVuoXZAEgKWAmyvBvXGau6/2k1GOll977LmwAwtNkAgCu776ewSCC/XIwXqq079pE7uo0m8lK/QVJQdDj5folWQBICtiyhmhw+Z35D1hyJFjr7XnK2z70XYgCecrbbvSIJ9Y/8KoeKf1ral1Wrn10q3aWJVmPlEBShJXeBdpuFHsEVwVBYXP0RBnkSl7zjX/QTRs7nPKZ8b1Pdu15Ojwy03vhyEwNtQNFd/1x50P+muz2yVfe4jfzz9qJg6ckCYLwFKBE7E7sSsEMwFjYkgEHBsmbV5j23CY0b+qQhRPnf7S/6/7PdHOP7MU2C5qnIW36zOCxr37RbfEflgnHOffjPju877gtHj0nzFiZWL9NzgteBJIE0eCy39Vim+/upOWful6SK1AeLOzd33nfjvBsVJ5rwgPzHZysOsUtR77yPifj7VFN3p3CkSidGEHxtfNhy3k9J7uiRrUnwVmWhH9tC/x1WUACemTq+WC8svup6+5/CrmcwO7ZwldvnRszj5ZtPf7VzcJVnxIJ9bdQdA0RNS2ySFeHanctW56E5Te4ol/kKf2/T6y///+BBRydraF2nA50IS+443dfzroJZGufbWXpT5FqV7ILQCMY/fnNXx+c+VtNm+t6QTd3y82cW9SOsiix+Vc51c09ElcQt/4CL3qJVrsCvtkAAAAASUVORK5CYII="


ICO_B64 = "AAABAAUAEBAAAAAAIADdAgAAVgAAACAgAAAAACAA9AUAADMDAAAwMAAAAAAgAOgIAAAnCQAAQEAAAAAAIADnCwAADxIAAICAAAAAACAAxBcAAPYdAACJUE5HDQoaCgAAAA1JSERSAAAAEAAAABAIBgAAAB/z/2EAAAKkSURBVHicbZLLa5xlFMZ/57xf5pKQySS0hmrSRt0Uq2iUWZS6cyEUBEEkFklw4WUjLlrcFKuC/ge6EpEipcZSUBAvC6FuBQ1tLXZEwSReYu6TNjP5Jt/3nuNiGtNJPcuX9/ecc57nCIAUAk/9+e6zm5cXxuO2qeLC7aWK5QYqHgqJlR/Yf/Xr+9+ctnZELriH9y6+8tHa+fpUe7YBQTuQO4iAOR4N6Qmd92gUDw4wOHH408kTH0wmZ+ffeWbtfH1q7ZvfYjJUws3ZaW+50VMt03dokMbMX2gpAYHmLytgTHxee/urpHV1qZbObVgYKiGJBgFwkETJl5uMvX6MwkLG6vdzJNUSHo1ksBzT+YY1ry3VVMRNVBTzW6ODBCWup1SevJdDLzxGuGF4QREEHDBHVFTAlL2lgqUZxYMD3H36KFX6CKmTrbbwNAfZ8/0OAXc8OiNvHKN0oJ/m+k2oDTJ68ii9jw7j7dhFdQmIKrHRZvilcQaeGEOakT9uLOLHD3DPqzWy5RbonoR3YSG2MvofH2H4xYfJVlp4dIIGJHNmT33LVn21k4T9j4C7Iz3K9t+b/Dr1BfWnL7Iy/TOFkX6Wzl5h49IcyVAZz61rgmR3d5BEyBabZP80iTfb9B7Zx+YPCyy8/yOhUsStG77TRKdzcUEojlUp3ldl/vR3eG6I3oqwixZXd1E3tx1zRMFaGX2PDLN87hrNy4uE/gJuvhuhCm5ubh6098F9M6XRisa11D23aO0YJdGY/t6IKxeuRykn0bay6JlF37bo0WK+vuXFkYr2Hdk/I5fckzOfvHxuffr6RDq7gXSOuWNWUEQ6q+109+gURysMnTj82WvPf/icAGgp4Xj9rcnNn5bGPY+Ku/w37m0wiEtQ733oritfjp35WETsX2hCPjMek6vIAAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAFu0lEQVR4nKWXXWgc1xXHf+fMx86uVispljaWLMtKUsdyTZAhqaGusWtoIA9uadKIgkvbl9JAoYQ8JLSlyWZpoR+BtOTBLXlooR9xMISQpKTQh1DaEILcgEvihGDTxJIlxVaq1ffuzs7c04eVZTuOpF33wNllmJn7/5378Z97hStRKinlsrty+X17s7DKvA8QsyrcRITkDMDDS5+VexfWpaykZWlqNRs2E0Tss6fGwj1jhx6qTy6MxRcWbnONNGze56YAEAxAfa+R2Vm4EA13v1h/a+7EX+4pr16BEKykSNnd9/HPB4PUvVB56dyB2efPUp9cxFKHSAvaBujav62Xdd29zI4CvQ/upedrd74tOX3gle4fncdKKiUr6d8h7JzyX595avzuqd+cjv3uyJfQa03bQFRwcYr4yqe+Y+AaqSWVWrL9m6PhwOMH3/d37fjcy0yuaFnKrictfGfhrx/cPXViPI52FkLNBSoqgmyd6qu4Riqdn+kVPwrE4MbnVESjQKOhrvCjP5yJ5188t0frlYeRslME6h8uHr988h3n92Q9lxo427p0ABXcakLmti5GHjsKsdv4WTNcwxH05vzZ58+62vn5r4/ZKU+/4V4txBeXhuPJRdWMpy2LrzVqZux64jDb+vtI6wmim4ybGRJ4Es8saXxxcTCkXlRHElrqfGtHGBBfSefrFB/aT++R24mWBfNa5HaGOfOMeqg+SXvKgHhCslCncHiIvu+OEi0LmSDEWXtNeQSm7YojzRkf9GYZeuIQZkanl0VFuHENbh1tA4iAq6UM/vAgmeFurJrSFeabjnMTftUWgPhKUqnRd3wfPcd2E89XyQQhHV6E4xMrwAxaGJGWAcQT0qWY3GiRgUcO4JZiTCDvZclqpmlI0PyxJqwEuiWE35o6WOLQrM/Qk4fRrI9bbqCeULU645ffJb61zp6TX22KB0q6FPPhY6+RzFURf2OQlnpAtFn9wCMHyI0WSZdi8ARBiC2hEi+x6jfI7r6F6I4ecncVmXvpHPHUEhp6m/bClgDiK8l8nZ5ju+k9vo9krtasaL1zBF881IR0uYFmfWb/+DYfnzyLX8hg6eZjsDmACulKTGa4i8EffB6rJayvtmvaNQxzhpcPqb4/x/TT43idIdaCL2wO4AzN+Az95Ahhfx5zIBkPCdYm2FUCRAVLHZPlf5Iu1luagLDVJHSGdgR8dOItZn49DirrXmMNx+CPv0BuZBvpcgO/N8v0L99keXwaf1sWSzb5MLUMoIJbabA8Pn1VXMFiR1DMERY7cPUUrzvDwmsXuPT7f+N1Ry2Lbw2wBqH5cP1SPCFdqJO/px+/L4erJjQur3Lxp68jnqz7QKvRmhE5uy4tcXTsvxUR0IzH1M/eoD6xiGaD1vcSbQFcE+YM7QjJ7etD8yGzz52l8up5/O5MW11/cwAiWD0lHMiTu6uP5dPTzDxzurnk2qx8HSCh2vInTBRcPaVjtIhGPhOP/wNXTTa12s0ipSHaSbEhnqRstpW6Jix1dB3Zxcwz/2LlzKVm9Vu43Y2FCIi4iFxDn+VLi+FA50RmoNO5OHUbggi42JEZKlCfWuLS787g97S35Jr+kVpQzFu4o3N6J/2XFRHLDned6h3bq8lc1amvfPrmHsAQVWb//M6aIbWxARHQwKPx32ra++CIRLtveaEsRxPFSpoL3G+7v3zHe9u/tT+oXZiPLU4cVx2/mYaJr9aYq1pSqZkEamtm31JanLraxELcd//eoGdsZKIjyj2NmWgJ+JM8uqJd+a8Mlg+9e/sv7g2joW4FBGfXZ2oiICIipHbj/Y0SJLOjoMPlL4ZDTx39T1iMjj0n36uUeHKtD9fOhwffe7Rz+8jAw7Xz8w9UP6jssoYL2unlDUYNfE2ioa7J6M5tL69MVX71t6Hy3NXD6Vpce2RGhW+nr2wXGkHK4v+F4FGwkCjp575LZRH3Sa3/AZf8p3p74NCzAAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAIr0lEQVR4nM1aW2xUxxn+/plzzl6Od+01Nhcb2yBIVUwIKBQMqROCSptIUdWXLuQhUaWUJKit1Fbk1qTINkkqSpI+tGrU5CUPUVXJ7kMbKU0KKQRxCaFBqBcIJYSbL1xtL7vrvZxzZv4+nLUx2Ajvckz7S+dlz+zM983888/3/3OAyYyZ1uzuMCZ99z+wJHdLMNNk7yaA7OAO0UWk9wDeuu6nqiNr5y+XYWplFgntaUBMM1oNCEOAidOUc4+njg0d7qH1VwAg2Z2UPet71Pjm17FKclL2UI9a1f392pnrFj5HUnxPj3izvcs56Jx3Q+tpNAYobMCsj4Di1iAU/yG779S2Xd9+qz/J3bKH1o+RGIM0yu4bh19YXXVX4l3vcmHBhd8dRmr3Ge2cz2p29R1CXwJmCJizbBFvbxINTy+H2RI7n/9y6Ikdy7Z9OJ4EjQf/rSMvrgwvqPn46l9PRU4/+5HrDRUMGTWJLBnQ7I92wrduygC7GjrnsrBN1dz5gFH3aCvnTqce2bn0Fx+MYiZ/c3RS+/uXqhOrmo+kd59t+eLJ9z1pm4YIGWDFAE9hwKlg1wBrBhk0JQ4gAkkCuwrecEHNe22dqNuwKFU4eWnpjhVv9HWgk8SajzslqEtX39vwPF91Wk4/+5ErbdMgS4I9HQx4AKwYwpII1Ub9fqeyosx+WylgJCLyXOce5ZxNJ6zmGa+AiI9hMYk9a7u8dTufqibL2Hj+rcPsDRWkCBmACgY44Puzmy5g3qY21C1phJdzQFSGT2oGmQJcVHLg14eYDNrw8MHn5vbQeiUAIHxX49fI0TNSu86wtE3BQYKXAipVROzBJix8ejXEiAaL8jcUKw1pm5Q+0Kc564XMebH7gdGoHg8t9i7n2Dk/oskUgbkNBEEXPZizbMzd0o6YiEzN9ydlAMAQ8Abz7JxLM4WsJdcICKrROZfYVUA5SzuVcR2FuS/dh2hzDWzXBBNXHtGIwEpDZR0CUAOUCBCYgwZOhoAaLmDm40tQ/dB8GGkNOxSFZr79iEyEUTeZFmFAkqAyRdjLZ2POj1fASRcQs2xYZEBX7EOTW/AECGBPQ9oWmjruh7AMsNKIm1HQNGiRwAmQEFBZFw2b2xBdXA+VLUIaEnEjGvjsAwETIEPAG86j9jtfQd2GVqjhAtgghMlCVIahWQe+BoERIEFQIy7CC2vR+MJq6Lzrh1HWsI0wLGGC/29XgEoaRwBNHe0wEmFoR4OIwABiMlqSQgwIX9/c+KCCww2YJKGpCL8U8AbzaNjchth9c+EN5kGGAIMhIFBrxiAgIEmAR1x4V4sQisD62ooQEYRt3nkCJAW8VAHxtS2YtXEZVKoAMvyFZTBMIeGyhyE3DSKJSNts1FYrmGELzOyfsILAjkLmYP8dJkC+VLBm2Wja0l6S3hg7aQkExRr/yp7xf2BG7AdLUC2XguEfaKwYRk0Yva/ux9VdZyCrrOtWZloJEAHaUZj70tcRao7DSxVAcuK2EmOMCJxz4bH/X/Y0ZE0YV7qP4cKbhyHj5YH3+64UvCHgDRdQ//gS1Dy84KbgJ45Y2rQAhG3BGcig/5efQEQMVCKSKiLgSwVnTCqodBEkyuyK/H76Xt4P5+IIREhWpILLJ0B+riptsyQVpL/sZUzeqOtceucfuLrrDIzqMCrNQcomQETwMkU0/HQloovq/NkHAM3XPzeZTVYMGQ8he2gA5988DFkdAuvKKx7lbWJBUFkHMx9bgplPLIVKFyFrwjcgRCmBZ+iCN+EdmQIqU0Rv116wpyFMWfbGrZyAZoiwgWJvGief/AvY0xPTCCJoRyHUGEPDM23XZWCsGUbcwrktB5A/PgijNuIn7bdh5YdRScgc6POlQ0kqXIdfErxUAXXf/SqEbZU2OIE9DSMRxtCfTuBK9+cwEuHbBl8ZAQZElVVKiia+JkmAZsTXtFxroxkiaqJwKoX+7Z9ARMzbcpvxVtlBpm+uK1kxZJWF6KI6cFH5JEp+1rd1H7yhgn9gBVT5CDahKVUhQvOqYTXHoR0F1gxZE8LFt48gva/XjzoBlm2CTWgIYFches9MX9M4CrI6hMy+Plx8+whkTSgQvx9v05ATE+x7Z4OVBlkS3mAevVv3jr0L2gIlwK6GOSOCaGsdOO9B2ib6tx9E4cthiKjpH3ABW3AEBEEXFcILEjBn2hC2iSt/PI6hP58ILGROOmxQHY33f3NGBLmjVzDw+qeQtgmexrsRAQCMSU6kMo3Zl9hVy2dDFxV6X94HlSki0Frr+MFKG6qU++mMCEsmQ1RWfC0pVGNGBFUrGzHwq08x8vcByHiwIRNgkBT+fiKdGSPAGeeYUR8lc5Yt2J3i5cN4/IKgR1zEVjYg9+9LfsicDr/3GLImjFBTHKqojo4RKPzn0mcIiXR1exOpnMtTyqzGGwNkEMw5VejfftAvkQRdLJYCKudybMUcSXHLc87n9wKAWLO7w/jbN387qJV+d86m5SRsU7GryqrTsGLImIXUjtPTEzJLdScQVMOPVhAzv7dz2aunk5yUYs+D0GCm7NnUK8Yc+3JL5wPSGy4oKPbLI1PhQT4J93IOZMrgwBNKeTbBvTyiG59ZJcKtM/JqIP0zMKgVrSxAXTrZs17saXv9Qv5s6rG6R1sx77V1Ujue5w3lmUdLCOLWj7BKhKfQ9pYPEVgxvKsFVtmi1/TzdtH4kzZR6M9u/GDZthPJnqTooi597aK7dHn80D9ffCQ8P/FO8Yvh+v7fHELmQJ9yB/MMdWcvuiEEjESYYivmyIYfrkDknvpssT+76cNFW38/4aL7RhJr929uiS2q74RAUqcc2zmXhso6/swErwaut1I6KqImrKY4ZCJUJCney3x+sXPXqjeO3fRTgzES4z6oWPfZ8832wtrVMOluMCWgNFhP/tVIYPgFMaQAWGdI09Fc79DBHXdvOwlcm+Bb99LRIZLcLacTaDmW7E7KDu6YNLb/F/EhAeCcDJq7AAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAALrklEQVR4nM1be2xcV5n/feece+feGc/4MU6Ckxg3oXHcB1XZBuhuE0K33ZCqPEUdBNoVSPyxQttFQspqEQmZTNukSC1FCBWxK1jQCi2SvUCq7bYpj0JpUkpL1JImLklTSOskbhzH7xnPzD3nfPxxZxw72Hl4rq/7s+4fM+N77/l+53ud73yHcAXIcU78GhDLe/u4d1uvuZJ7lgq1sX4QsHnK28v9P136aTnRvfsG6qVtZuZ3G+8cbMRYvUONFo2NjXirb3jy0D//Z1D7Lsc5AQCXImJeArq5R9YEv6sv1ylc+gQ8sYmk7CSBVubLkBc3CABjhLU9gcA+x4Xyvidu3PsyMFuWuW77K9Ru+NBL/36Nak7uEin3006z7wWDBZROjiIYLABEAPPiCXQ1IAIsQ2V9eB1NcNsaEIyXrC3qn5rR4n37b3rw8Hwk/BUBm3+VU8/cntdbXvnKJ93W5H+42VR25Bd/wvl9x/Tk7wcoGCwSl83ba/YBAAxyJausz6mb38EtH1mnsnevg54ol/RY+UtPdua/MxcJswSpCb+1b+eXvFWZRypDRfQ/eFCPPH5CclmT8ByQIwDxNpQfACyDtYUtaZAgZG7v0O07NqrU+lZMvTH88JNdD/xbTcbaLdOSdPf0yN5t28yWozs/nlyd+enUG6Pm9S88ScUjQ0I1eyAisOV41D605wXfS9UJ0qNluKvTvPbRD5nGW9tV8fjQF/ffuOdbMzWBgNBb5rGbt762e5X05REOOH38nx7D1Kuh8BxcNppEByKwsdNC1PUoJWAmK3CWJbnzhx817soMVc5Pvu+p6/e+lOMc5SlvBQD04QYCERPsA4kV6cb+PQds8ZVzSyO8NlC+Ezq2OsHaQja4qJyZpDd2/Yak70jhqEcwQ79EjnOil7aZuw/n1sqM95mRp/9kRx4/IVVLzMILgp0K4HU04trP3wpbDCLxNawtVLOHiQOn5Lkf91l3RcPmrUd2bMxT3nZzjxSPHxqQAGBcu81tTTnnf3LMcsUQRTADVwMCYLXBmp2bsezaldDlAJGNgRkkCcP7jlvhKKaE+EcAGMRREmtvGbEAIDz5gWCwgMkXB0h4Emzjm31SAnqkhNbPvhttW7vgjBmwiO75bBnkKRSPDonSiWESnvo7AHgGeSN6qdd093RLclVn6eQognNFIkcu3AtfJUgSzHgZ6fevwop7b0GyIKGUA0aEqSZXHeJYmYqvnYdwVMcdP/+XLKjK80CyNUOCssFgAVw2FFucJ4ADC9mYQPuujSAlkCb/ciuUhb2KQn8QvFUAlMioxmQrAESoaAsYlCCYQoBV22+F15WFKBpkEklYtqCYlhpLRkDN7rP3dCF7TxcqI0UkXR++SMDGZX9YIgLCma/A78pi1fZbYQsaTEBa+VAkwTEusuIngKpeWQm079oE2ZgABwYgIKNSsQ8ndgJICpixMtru3YD0+1fCjJcBSZAk0KD8qvrHl4PESgBJgh4toWnLGiz/3E3QIyWQErBs4YsEkjJRdYDxIT4CBMGWDNyVaazecRtYh4kWgWDBSEsfDqnQ/cXIQKwawNpi9Y7b4K5Mw5bMrFw/48Rv/0BMBNRC3vLP3YSmLWugR0sgWROeISCQVj54CQqNi07AhVR3Jdru3QAzVgbJC6+1zPCki6TwYBHj6rOKxSVgVqq7CaREWFWi2s8EC4sG6cEREhYMriVBgi59RQQV2ZPmAAmCHq+gY8dt8Luy0MNTIDWbcwaQdTJwSMGShSMUhAVsIYBNBLBmDq1ghvCdSMa4aASQEtDDU8h2X4fsPV3TIW8mGAxJAkPBGCZMEZYZ8qzExHs8rP/vj0EqObsGSQBrhmxMYPAHhzH2y5OQKSfUqgViUQi4ONU1hWDeGh+BMFQZv6D6JYZoVmj+YMfs+isB0BYyk8DE86cx8dvTEL6qO22OnoA5Ul0zUZnh9ecYBAnMcAxgzdATldnFYcsgRyA4OYaT238JWwpCM6hj9oFFcIJzpbqXEh4IheQZf9OlbUGg6gUiyKSLMw89j/Kb45Apt27hgYgJmC/VrRe1wuZQbx+G/+81qKbEdCZZL6IjYJ5Ut16wZcgGF8Wj53D64d9BNtTn9C5GpBpwqVR3YQ8MTYEDg/77DsAWKqFGRVguiISAS6e6CwebMIkaePQQCr8fgEwnwCbaYkndUaBm9w0b2vCOL/wN9HAp9OSXGWjo+OcniQ1DNXkY/dmfMfj9w5DNXmRmNRP1EUCArRgkVqex5pE74bQmYYrB5WefCLakwWUz99KXGSIhURmYxKm9ByNxpPOhTg0IGxNko4ez3/sDbLECEpcZrCDYQgWNf38NmraunTNJYgaEK3HqwedQOT0B1bQ4sw/USwAzyJUonRhG8fDgFTk9kgQ9VkZ6Y/ucDo21hWrxMfhff8Do/tehmv1FEx6IIhNkgFwJ5V3Bo6pb396yJBpuaYOd0rNmnw1Dpl0UXj6LgW+9GDq9Rd6ii8a4OBz85S5Yhi1qeGub4LalwJUZPoABUgQ7pdF/37OwZQNStOhbdPFWhQngwCD17uWgxOyFDNtwL//MN15A8fAgZIMbecibC/HWBKvmktrQFtp1NQyytlBNHkaeeB3n/ufoojq9ixEfAdXZd5Yl4a9rAZdNuP9vGcJXKL85jlNfew7Ck7F238VGABGBSwZ+Vyuc5cnp3SAgzCRP7TmI4GwBwr2oCLLIiFEDwgiQes8KkBPOMmsL2RTmEGNPnwxVPwa7n4nYCGDLEJ5C6qbl4exbhswkMPnCGbz17UOQmQR4rvrfIiMeAgjgioG7Kg2/syVsZHQlzEQF/fcfABsO84El6LyNZ2NEEGxZw+/KQjV74IqFTDk48/DzmHp1qO7CZj2Izwcw0LChDcyAbExgeN9xDPW8GhISU8ibC7EQwJYhUg6SN7SClED5z6M4/dBvIZIOeOlkB1AlQKsKAUyLEn4EwZYNEu0ZJNY0g0sa/Q8cRDBcgnBF/C331fexCDveBQAkEqvH2WBUZZMgV3CUgyICuGyQvK4ViY4MBh49hIkD/VCN0Vd3LgXmcCWqWpNgYwt6VI8A1VbZZ27Pa9b6hHdNE1SLzxzYSPfo2TAym9+J8Wf7cfa7L0PGmOpOwzBE2mV/XQtsYPqfvuObgwAw3SrLJXvQbUsjdfMKrvXbRwEOLNwVSbir03hz5zOAiKQP+qpAIqxA+etbbLIzyyjrF0DEmzmnxIdvaTMAIAz1BqNT3PKxTkGCotHNavjz1rXg3A+PhCEvuQQhr1pZbr57HUEQYcr8CACW4wYmAOju6Za923rNXcd2Pea1N3702Gcf02O/OKkiCVHVjM9MVuoXZAEgKWAmyvBvXGau6/2k1GOll977LmwAwtNkAgCu776ewSCC/XIwXqq079pE7uo0m8lK/QVJQdDj5folWQBICtiyhmhw+Z35D1hyJFjr7XnK2z70XYgCecrbbvSIJ9Y/8KoeKf1ral1Wrn10q3aWJVmPlEBShJXeBdpuFHsEVwVBYXP0RBnkSl7zjX/QTRs7nPKZ8b1Pdu15Ojwy03vhyEwNtQNFd/1x50P+muz2yVfe4jfzz9qJg6ckCYLwFKBE7E7sSsEMwFjYkgEHBsmbV5j23CY0b+qQhRPnf7S/6/7PdHOP7MU2C5qnIW36zOCxr37RbfEflgnHOffjPju877gtHj0nzFiZWL9NzgteBJIE0eCy39Vim+/upOWful6SK1AeLOzd33nfjvBsVJ5rwgPzHZysOsUtR77yPifj7VFN3p3CkSidGEHxtfNhy3k9J7uiRrUnwVmWhH9tC/x1WUACemTq+WC8svup6+5/CrmcwO7ZwldvnRszj5ZtPf7VzcJVnxIJ9bdQdA0RNS2ySFeHanctW56E5Te4ol/kKf2/T6y///+BBRydraF2nA50IS+443dfzroJZGufbWXpT5FqV7ILQCMY/fnNXx+c+VtNm+t6QTd3y82cW9SOsiix+Vc51c09ElcQt/4CL3qJVrsCvtkAAAAASUVORK5CYIKJUE5HDQoaCgAAAA1JSERSAAAAgAAAAIAIBgAAAMM+YcsAABeLSURBVHic7Z17cNzVdce/597fY9+SLMsP+RWDTTAYSIDYCS+baSghgZA2s55MCZlM0zw6TaYwg9vSgFcLpCGhLUxhMoGkTRuTEKwOMyHl0ccMNo+ATSAQbPOwTeKXZCNZsh77+v3uvad//HZtyVrJki1Z+9DHMx5ptbu/3+75/s4599xz7w+Yoa6hM3Yk5jN3rJqAAAKfgaNMAamUSLadTx9gB81p38ntyXZzJj5MrZHilNi8GQIA1q6FSSPNk/09Tp4AmCmJdtGOdWWNfWPv/Y04ehRqoDDjCcbAirusmkIU+Z/X+9vXtesT/57kTfI87OA0pc1kHO/0jVEyPK07drI3HvnHRSqTvxTgS9jXH4NAE4GWGcNnMuhUJ8wQtoTx9SFhiU6yxe+I6E1i2tb3rvfelqvTCpg8IZyWOZK8SZYMf8Oe2+eaUOyzZPjLRuuPWBEnQpYAexqsDXRBgYgwEwhOAgFcFAHZEsISAACV8RRJeo8J7eSpX/zX0vQ7QNEGo3jdcR7uFCgldER8w57b5xon8pcgfMMKO3ONp6CzPtiwJlswOYLIEiBBYsb444QIbJhZG4Zv2HiawJAybEGGHeisV2Dwz1HQ//zUsvR2IMgXTsUbTFgAQ6/6T++7+1tC0h0ybM9R/XloT2vhWiQjFrEypI7kUDgwAL9zEPk9vYCY8f8nhQBWBk5rHO7iBJzWOOyWCETEZpNXrHM+CyJpN4ahC8oDm4fzhzJ3/t+l3+sbapsJHG78lA5w7c6/ny/joZ/YUfdaNVCAKfhKRBwpHEmFfX0Y3NaJvs17kd3ZDdWbh8krQE9KzlIfMABJIEfCanAR+lAjEmsWI37ZQoSXzwIksRooGEEk7VkR6Jz/ns4V/vyZZXe/NFERjFsAazhlbaG0um73nZfLkNMuQvZ8vzejyJJSxhzK7uxG16Pb0f/cXvg9OYAIwpUgWwSxn2au/onBYAOwNuCCBvsaMu4gevF8zPnSSsQvWwjWzCbjaRl3LQIp7fvffHpJ28MTyQvGZZVjxt+14atWLPQDVtpSWU9biZDUAwV0PvQaep54BzrjQ0ZtkC0ADpKZmbh/mhAAIhARWBuYrA8QIXHlIrTethrh5bOgenOGLEl2Q5i8/vzDzyxNfSPFKTGeusFJBVByKde9u+GrdlP4EZXx2HiK7VlhMfhqJ/alnkd+Vw9kwgVJATZmxuhTCBXzKD3gQSZctN62GrOTK6D6CwywcVvi0use/NHTZ6e/Np5wMKYAjsf8Oz9hN7gvGd+w8XzYzRHR/dhOHLjnRQCAiNhgNRPjzyQkBdjX0IMeWr64EgvvuAIm44PBfqglbuc+GLj12WXpB0ree9T3GfUInBJAmm94//Y5xg7/johadM5juzkiuh7bgf2pFyAiNkgS2Mxc8tMCEUgA/pEcWm5aiUWpK2EyPoOgZcSxVH/uj5855+7/HcsTiNHeO4mdBAJr4W60Is4clfWM1RQWXY/tDIwftQExY/xphRmsGfbsCLp+vgP70y9ARCxiYwT7milkb7xmd2pOO5ImuKBHUvbBQDHt+rpdG/7Kboxc4/VmlJUIycFXO3HgnhchIlaQ1XMdGb+YjFUirAzs5jC6Ht2Oro3bYTWGhcp6xo65cy3gIRBxEjvLnvzIB4tVvs8d/O4sX/u7QKKBtSH2Nb130y/h7e+HCFn1deUXM3A2BsKWlZnkFi3JvsHyf78ekQvmQg8WtN0Ylnowf/VTS9Oby4WCER4giXYBIi4UCt+y4+Emk/eMjNnU+dBryO/qCRK+OjO+8RXcxjDii5thPF2ZjoARDBWVwYF7X4EpqKDyasBGcwoAzsOOEYYbLgBmasc6c/07qdkkxDf9/jyLiCOzO7vR88Q7kAm37rJ9IkANFnDO36xFy4pW+DkPoFFTp2mFDUPGHGRe68TRp3fDSoSk35dlKxZa+5nfp9amKW2SvEkOfc2wT7IGbRIE1g79id0QataeMsKR1PXoduisD5KV+cGnCpICut/DrHXn4qw/uwSm3w+uqkr0ACU0Q4QtdP1sB3RfHmRJIywJY/C14Antw54+zKJrAZPclJQA/sIUNIuQhcK+PvQ9t7fo+uvn6idB0DkfobMbsWD9JxArOMHjlWx8BNVXClvIvt2Nga0HISK29PtyTFLc8Nm3U63t1K6HtueJIa+kNKVN9qLl84Sk83XWIxmyxOC2DqieXOUmP1MBBe6UBGFh25UIxSKIsQum6vgCqOii+rbsB0ki1sZYUTfmh+QqoJjnFTn2Q+lBduzVMuxE2bBmbajvuX3FRo7q+PCTAQkBPeCh9ZZViKyaj1COELJdaDaobP8fwMZAhCwMbu2AfzgDciSTIMCYqwHgA+wY6QFKD7Lhj5ElQLZg/0gO2be7QSEZTOzUASQJqj+PhjWLMefmC+AfzSHhxiArNPErCwPkSHgdA8jv7gGFJBVHLxcjlRJrgWOx/NinGvLgR4xvQI4g/+AAVG8eZIn6cP+CYAoazvw4FrVdCeMbEAgNdrTqLoDSkDC3+yiEEMLkfTBwzme/kI2mKW1KeYBVekEb2ngzw6Lf02xWBmQJ8joGwHkFijt1EwLYN1jUdiWc+XGo/jwcy0JMhsHBQHu6T2+CMLwD/cFPhpksETE60gRgAGgjABx4AGYiInZ39CdAWM4FBRJE+T1HwdoEOUCNQ1JAH82j5eaVaFizGLq/AJYElxy4wkZ1RP8hMIOkQNGGxMawDNkxxMRyAEjifAJOGAbaxmXm4/GhXnr4SBL0oIfYqla03rIKesADCYJhg7gVhk0SzFU6BB5qQ2aYofbFGLOBdQMBxjeQUQeL77oKVJrhLHq9RjtW0+lP3QuAiGAyPlrXr0bo7CbonB+IAAYWScStMEz1BYBxU9cCICmg+gqYvW4FZq9bAdVXOFbuNgDCwkVYuDBsatT8dSyA46XeJrSuXw2T8Y8lu4Tj8d8iORMCao4hpd7Fd10FGXVgfDPCyzfasek5vzNIXQpgaKk3tqoVetADyePWPzH+U80GgDoUwNBSb8vNK6GP5odNcxNOjP+1HADqTQAnlHrZLze2JxhmRKRb8/EfqDcBYHip1xR02WIXg9FgR4uOv7YlUDcCOLHUq/rzw+L+cRgSAgkrAl3jxgfqRADlS73lP7oBIyQdRGQQ/2s5AQTqQQCjlnrLPZWgmRGXYThkBTOANU7NC2C0Uu9oHI//hFqP/0CNC2CsUm956iv+AzUsgLFKvaOhwQhLBxEZqov4D9SqAMZZ6h3+EgIzIyzcYP5/xgNULycr9Y6GASNhRyDqJP4DNSiAk5V6R4chQGiwojB1Ynyg1gQwrlJveQwYrrARraP4D9SaADC+Uu+JULH+H5WhYgPojAeoOsZf6i2PKY7/6yn+AzUigImUestTn/EfGLIwpGopU+o1xSHgeCnF/4gsrf/DsGEgF/9BEEiK014mzxW0a2rVC4CIoDMeFt5zGUJnN0GNO+svvh4EzQZxO4yoDEGVaQBlYtjCghn04PfkIPWpG5ENYCWcillzUdUCICmgjuYnUOotDwOwyEKPNwAFPWIEwMywMjkkPrcMCy+MwQ6d4jY5DJArcWTT2/CPZCtizWXVCuBUSr3lYDAsEvjA68WhQs+Yz3VvXILF1tKJL5MkAMpANoZw5D/fht+dPbad7nRTnQIoU+rVg/6Esv6Rb0mwxhQQwQx40KfSI2gYImQj92oH9v7d5mPvVwkKqEoBkAhc/8LbL0NsVStUb25S9i8a2xzFJHCiBSIGIAEQsP+uF2HyCjJmg/X0Gx+owmHgqZd6pwc2BjLuoOOBbRjc1gEZcyrG+EC1CeA0Sr3TAWsDmQihb8s+dG3cDtkYqqghIFBtAsCplXqnBcMQrgX/8CD2t70QJH0VSGWeVRlOt9R7pmEAZAsc/P4r8DoGIFwLqMAdVqtCAKdf6j2zsDKwZoXR/dhO9P5qF6yGynP9JSr3Wywxga7eSoANQ8YdZN88jM4HfwOZcCp6g82KF8BEu3qnFS6GqkEP+zY8X+xEqoyCz2hUtAAm3tU7vbAxkAkHnQ/+Btk3D0PGnYrfWb1iv83JKvWeKVgbWA0h9P5qF7of2wlrVrgqdlavTAGcQlfvtFIc8nkdAzj4/VdAdvXcJbciBXCqXb3TCdkC+9tegH94sGKHfOWoOAFUXalXB7N8XRu3o2/LPshE5Q75ylFZ32zVlXqDO3QMbutAxwPbiklfZZ/ziVSWAFBFpV4GhC2gM8GQr5SzVE3wL1Ix08EkCX53DnO/chESVy4KpngtMSXDqMmoI7BhiJiNjg2/Rn5PL6wKnOgZD5UhAEHQGR+Nn1yKhXdcAS52z0wJBJicOq0krVTq7XnyPXQ/vhNWU3UaH6gUARiGsCUa/mgJBl45CDNl1b6gjBw5txki7pySCNgwRMRGflcPDt77MkTMQbXuIw1UigAAwBI4cM9LQfFkKmIpFa/chhA+/MSfQgoKGjMmqDOiIIQcuPdl+N3Zip7oGQ+VIwBmkCtBoak5JRLBjGL0I3PhzIvBZPwJJ5gl19/5L6+if8veqqn2jUXlCAAIrvqp2piRCOxrRC5oAdkSzN6E+vtYG1iNIfRv2YtDP3wdsiFU9cYHKnAYOFUwM8iSiF44JzDcROYVOMhR/O4sDtz7MkhQ9d09ZhTqQwAEsKfhLIgjvKI5uA/SBCzIBhAxBwfvfbnm7p9cFwIgInBBIXJ+C+yWaFBhHKf9A9fvovvxneh9ancw5KsB11+iLgQQ3P6dEb1oTvDzOIcYbBgybCO/pxcd920Fha2aufJL1IUA2BiIsI3IBS1gX48v/jOOtZ/t2/A8dMaDqJDlXJNJ7QugFP/nx+AubQR7elzxv9IXdEwWNS8AEgKmoBG9ZB7sWWEYX580/lfDgo7JouYFAABgIPbRueNL/KpkQcdkUdufDoDRgSsPn98CUzAnXU9QLQs6JovaFgABKCi4ixJwFyUAT43pBappQcdkUdMCICFgfIPIyhbIuAMzhjHZMGTUQfaNQ1WxoGOyqGkBMDOICInLFwZTtqNl/6UhnzbYf/dL0AOFiti+5UxQuwIoTf82hRD6cPOYwz82BrLBRccD25B54zBkwq3JIV85alYARAT2NNyljXBaY2Cv/PBv6IKOrp++Bdng1lSp92TUrABQFEBkZQtE2C4fz09c0OHIM3+e00zNCoCZQbZE7NJ5QSZfzv1T9S7omCxqUwAEsK9hz4kgcuEccH5k/GdlIBNusKBj896qW9AxWdSkAILpX43QslmwmyPFCaDjf2fNkHEXmTcOBws6Em5dDPnKUZMCCKZ/DaIXzQE5Ejy0zYwDt28yHvbf9SJYm6pc0DFZ1KQAxmr/YsMQYQsH73sF2bc+gIxW/hr+qaT2BDBG+1epLtD71G50P/42rKbq7+o9XWpOAKO1f41c0FE7fX2nQ80JYLT2L8LwBR3CllPXgl5F1JwAyrV/sTKQTWEcevj1YEFHDTd4TJQRAiAQD/mluijT/gXDkAkXg1sP4vCP3yzW+evI+HTir2KY2xsmAF+4xGC7NCSqtgRpRPuXpyEcCdWTw74NzwOq/oZ8Q20Y3E7H2EP/fkwAzEwN/f05AvYHY2ew0xqv3A0aRmNI+1ewhr+4oGN3D0S0jhI/CjqandY4SBATCdKeypHyDwDAedjBQEkARNyGNmq/7P4cM3eSLcDasLs4AWGfUEipYIa1f2UV7KZwzS7oGBeGEVqSCO5zIIhMQedNb99BAEijbYgAAOzE+cXBMr8rbAH2DDsL4pCNLlidvJN22hnS/uW0xkG2QP792l3QcTKCYphA6KxGGM1MrgQR/2GxVcgxM4FouAA+wA4CAJLWqwDAvia7JQL3Q41gz1T0Jo3A8PYvq9GFySvsSz0PnSnU5IKOMTnWDBOGe3YT4GkjXAvM+N0jlz7ir0P7Mbsf+2Et2gwAsNG/9rO+RwwhwjYa1iwe/2qaaaTU/hVbvQAy4eLwv76Bwa0HIeP1091TgojAOYXoxfPgLmmAzisiIpDAZuD4xQ4MEUCayIBBsRz+wJ7aK8M2mbwy8csXQEYrfOhEQWePSDiIr5qP3mf24PCP3oCs11JvcTIscdUiEBEEQaiMp9jg18Dxix04YRi4BinZvjLtQeDnImLD5H0TXt6M6CXzYLKVu0s3EcHkFCIrZgOCsO/bmyt6c8kphQDjKTgL4khcsRA652srHobx1QurfordKU6JNFF5AWwBgjDgq40q4xUIJCGI53xpZbGsWqFQsL9g7OJ56HzoNRT290OE6q+7Bwh2WDeDPpo/fy6chQmYvAI5ggD8OJ1Om80n2Hz4ZUJpk+RN8tlzvrNHF/zH7aYIqYGCiV+2EIkrF8EMFCpyz17WDKvRReatD9Dzy/eqetu204IIJq/gLEqgOXku9IBn7Jgr/N7cu1mBJ5iZtqBND33JCD95HpIMBrEw/6CzvhKWACvm1ttWQyZClbtrNwODr3YGAq2/Cx9AsdKXU2i9dRWcuTGwp4yMOERsvrtlaTq/Du2iNPwrMUIAaSKTxCbx32fd864p+A87jRFpsp4OL29G622rYQa9ys0Fanwh51iQLeAfyWL2uhVoun4Z/L68thJhy+vJ/lab3l+kOCXakRzhFst+Y+1ImhSnhOVnb/f78+/LuCtVb87MTq5AyxdXwj8SbONacdTrlW8JqN48Ype2YsH6j8NkFQtbMmujjVBfefacBwtAG068+oHRpoOLT3xyxX0DOpO/CUxMjmTdX+CFd1yBlptWQpVEUJnOoG4gK7iNbvSiuTjrB9eCXAnWWjlNEUtlCrc9u/Se3yZ5kxya+Q97/VhvnuRNsp3W6Wvf3fD1UEv0h35vTgGwRMzG/rYX0PXodlizQkHhoQ4z7mklKOzAP5JD7NJWnPWDayFjDkzW9905cbtwZPA/njk7/eU1nLK2UFqN+jYnO07pDa7bk/qhOzv29ULXoE9ElohY1LVxOzoe2Ab2zfEbJM0IYWqh4lAvr2ByCrPXrUDr+o9DuBImp3ynOWr7g4VXhaXXXtKKfBptXM71D3m7k8CgNUjJLZRWn/59+hGnOfrVQteABjNZjWGRef0QDnzvZWRe64RwLYhIsPkoG8y0XE0WFBS7QATjKZhBH86iBFpvXYVZ1y+HzvrMSmm3JW6pgcI27s186qkL7+0FpwQoPeZ4eHwRnJlSaKM0pc1n9qZvEa59P/saOucpGXctU9DofXo3un+2A9l3ugEDiLAFcuTxKYQZLUwMKv7HDKMMOKfA2sBZEEfz589Fc/JcOPNiUEfzmgQJpzlGKpP/N9Hff8uTK+4bCCp+Yxv/2GHGe0opTgUi2HXntQjZP7Ei7nzvyKCBFGw1hKQ6msfgKwfR//x+DGw7CK9jMOjKLU5NzjB+SuGULAFrVhjRj85F4qrFSFy+EM6iBPSAZ9hTxkqELdZGsdLrn1qSeiB48cmv/BITzuHXPJeytlydVp98e32rE0v8k+VaXwAz/L6cgRQsY44gQeQfziC3uxf53b3wDvQj//7RqdkGvsag4lSu3RqDu6QBobOaED67Ec6SBpAg1lnfmLyCFXWlFXGgct5WU9B//fRZqa0pTomTxfwRxzuVkyyNDgDghoPfucYYs15Y4hphS/j9eRhltHAkkytJWEKAAVZmIptz1zcMQBKTJLBmw55mnVdEIGnHXZAtoXPedjZ8/6FnDmx87euP+ENtMhFO3SRD8gKgKATmm2H4Rhm2EiQIxtMweQU2DDZ1uvryFCEiAUGQrgXhWAABOusrCDzHzI/qt7oef/bTDxYAYLzxvuxxTvdEk5uSsj25yZTczqf237tQCvUx1uYqMnyx0XweCFE76oRnBgXjgBkkBfyBghYC/bDkboC2E4kXhOCtT7Z+e2fpqcWr3uA0AuukOeXkpqREMokT3dAn9/xtQ9SNJViKZSo/aj1ihhJKwWqMQfUMHLLnNHf+sunWo8P+zkxJtIt2rDOoyBn6VEokeZNc81zKSnFqJvU/fWgqv8+pT8uYCW1tlGw7n4B2AMkpP2R1E3xH52EHTzSjn2GGCfP/CchRiGvArWYAAAAASUVORK5CYII="


def ensure_ico():
    """Embedded logo se .ico file banata hai (taskbar icon ke liye zaroori)."""
    import base64
    path = os.path.join(APP_DIR, "fastlauncher.ico")
    try:
        data = base64.b64decode(ICO_B64)
        if not os.path.exists(path) or os.path.getsize(path) != len(data):
            os.makedirs(APP_DIR, exist_ok=True)
            with open(path, "wb") as f:
                f.write(data)
        return path
    except Exception:
        return None


def set_app_id():
    """Taskbar me Python ka icon na dikhe, apna logo dikhe."""
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("FastLauncher.App.1")
        except Exception:
            pass


def set_logo(win):
    """Window ka icon (title bar + taskbar) set karta hai."""
    if sys.platform == "win32":
        ico = ensure_ico()
        if ico:
            try:
                win.iconbitmap(ico)
                return
            except Exception:
                pass
    try:
        img = tk.PhotoImage(data=LOGO_B64)
        win.iconphoto(True, img)
        win._logo_ref = img  # garbage collect hone se bachao
    except Exception:
        pass


# ---------------- Mods window ----------------
class ModsWindow(tk.Toplevel):
    BG = "#0f0f14"

    def __init__(self, parent, get_version):
        super().__init__(parent)
        self.title("Mods")
        set_logo(self)
        self.geometry("640x720")
        self.configure(bg=self.BG)
        self.get_version = get_version
        self.mods_dir = os.path.join(MC_DIR, "mods")
        os.makedirs(self.mods_dir, exist_ok=True)
        self.hits = []
        self.offset = 0

        tk.Label(self, text="Modrinth mods: list se chuno, naam search karo ya link paste karo", font=("Segoe UI", 13, "bold"),
                 bg=self.BG, fg="#4ade80").pack(pady=(12, 4))
        row = tk.Frame(self, bg=self.BG)
        row.pack()
        self.q = tk.StringVar()
        entry = ttk.Entry(row, textvariable=self.q, width=38)
        entry.grid(row=0, column=0, padx=4)
        entry.bind("<Return>", lambda e: self.search())
        ttk.Button(row, text="Search", command=self.search).grid(row=0, column=1)

        lb = dict(bg="#14141a", fg="#cfcfd8", selectbackground="#4ade80",
                  selectforeground="#000000", relief="flat", exportselection=False)
        style = ttk.Style(self)
        style.configure("Mods.Treeview", background="#14141a", fieldbackground="#14141a",
                        foreground="#cfcfd8", rowheight=40, borderwidth=0)
        style.map("Mods.Treeview", background=[("selected", "#4ade80")],
                  foreground=[("selected", "#000000")])
        wrap = tk.Frame(self, bg=self.BG)
        wrap.pack(pady=6)
        self.results = ttk.Treeview(wrap, style="Mods.Treeview", show="tree",
                                    height=6, selectmode="browse")
        self.results.column("#0", width=570)
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.results.yview)
        self.results.configure(yscrollcommand=sb.set)
        self.results.pack(side="left")
        sb.pack(side="left", fill="y")
        self.icons = {}  # icon url -> PhotoImage (reference rakhna zaroori hai)
        brow = tk.Frame(self, bg=self.BG)
        brow.pack()
        ttk.Button(brow, text="Install selected mod", command=self.install_selected).grid(row=0, column=0, padx=4)
        ttk.Button(brow, text="Load more", command=self.load_more).grid(row=0, column=1, padx=4)

        self.status = tk.Label(self, text="", bg=self.BG, fg="#9a9aa8", wraplength=520)
        self.status.pack(pady=4)

        tk.Label(self, text="Installed mods", font=("Segoe UI", 11, "bold"),
                 bg=self.BG, fg="#e8e8ee").pack(pady=(6, 2))
        self.installed = tk.Listbox(self, height=6, width=72, selectmode="extended", **lb)
        self.installed.pack(pady=4)

        btns = tk.Frame(self, bg=self.BG)
        btns.pack(pady=6)
        ttk.Button(btns, text="Remove selected", command=self.remove_selected).grid(row=0, column=0, padx=3)
        ttk.Button(btns, text="Add .jar from PC", command=self.add_jar).grid(row=0, column=1, padx=3)
        ttk.Button(btns, text="Open folder", command=self.open_folder).grid(row=0, column=2, padx=3)
        ttk.Button(btns, text="Modrinth website", command=self.open_modrinth).grid(row=0, column=3, padx=3)
        self.refresh()
        self.search()  # khulte hi sabse popular mods dikhao
        if not HAVE_PIL:
            self.say("Mod ke logo dekhne ke liye CMD me chalao: py -m pip install pillow")

    def say(self, msg):
        self.after(0, lambda: self.status.configure(text=msg))

    def refresh(self):
        self.installed.delete(0, "end")
        for name in sorted(os.listdir(self.mods_dir)):
            if name.lower().endswith(".jar"):
                self.installed.insert("end", name)

    def search(self, append=False):
        query = self.q.get().strip()
        if not append:
            self.offset = 0

        # Modrinth link paste kiya ho (jaise https://modrinth.com/mod/sodium) to seedha install
        link = re.search(r"modrinth\.com/(?:mod|project)/([A-Za-z0-9_\-]+)", query)
        if link:
            slug = link.group(1)
            self.say(f"{slug} download ho raha hai...")

            def install_link():
                try:
                    install_mod(slug, self.get_version(), self.mods_dir, self.say)
                except Exception as e:
                    self.say(f"Error: {e}")
                self.after(0, self.refresh)
            threading.Thread(target=install_link, daemon=True).start()
            return

        self.say("Mods load ho rahe hain...")
        offset = self.offset

        def work():
            try:
                hits = search_mods(query, self.get_version(), offset=offset)
            except Exception as e:
                self.say(f"Error: {e}")
                return

            def show():
                if append:
                    start = len(self.hits)
                    self.hits.extend(hits)
                else:
                    start = 0
                    self.hits = list(hits)
                    self.results.delete(*self.results.get_children())
                for i, h in enumerate(hits, start):
                    desc = (h.get("description") or "")[:60]
                    self.results.insert("", "end", iid=str(i),
                                        text=f"  {h['title']}  -  {desc}")
                    self.load_icon(str(i), h.get("icon_url"))
                self.offset = offset + len(hits)
                self.say(f"{len(self.hits)} mods dikh rahe hain (Load more se aur dekho)" if self.hits
                         else f"{self.get_version()} ke liye koi Fabric mod nahi mila")
            self.after(0, show)
        threading.Thread(target=work, daemon=True).start()

    def load_icon(self, iid, url):
        """Mod ka logo background me download karke row me lagata hai."""
        if not url or not HAVE_PIL:
            return
        if url in self.icons:
            self.results.item(iid, image=self.icons[url])
            return

        def work():
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "FastLauncher/1.0"})
                with urllib.request.urlopen(req, timeout=20) as r:
                    data = r.read()
                im = Image.open(io.BytesIO(data)).convert("RGBA").resize((32, 32), Image.LANCZOS)
            except Exception:
                return

            def apply():
                try:
                    if url not in self.icons:
                        self.icons[url] = ImageTk.PhotoImage(im)
                    if self.results.exists(iid):
                        self.results.item(iid, image=self.icons[url])
                except Exception:
                    pass
            try:
                self.after(0, apply)
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    def load_more(self):
        self.search(append=True)

    def install_selected(self):
        sel = self.results.selection()
        if not sel:
            self.say("Pehle list me se mod chuno")
            return
        slug = self.hits[int(sel[0])]["slug"]
        self.say("Download ho raha hai...")

        def work():
            try:
                install_mod(slug, self.get_version(), self.mods_dir, self.say)
            except Exception as e:
                self.say(f"Error: {e}")
            self.after(0, self.refresh)
        threading.Thread(target=work, daemon=True).start()

    def remove_selected(self):
        for i in self.installed.curselection():
            try:
                os.remove(os.path.join(self.mods_dir, self.installed.get(i)))
            except OSError as e:
                self.say(f"Remove fail: {e}")
        self.refresh()

    def add_jar(self):
        paths = filedialog.askopenfilenames(title="Mod .jar chuno",
                                            filetypes=[("Mod files", "*.jar")])
        for p in paths:
            shutil.copy(p, self.mods_dir)
        if paths:
            self.say(f"{len(paths)} mod add hua")
            self.refresh()

    def open_modrinth(self):
        v = urllib.parse.quote(self.get_version())
        webbrowser.open(f"https://modrinth.com/discover/mods?v={v}&g=categories%3Afabric")
        self.say("Browser me mod chuno, uska link yahan search box me paste karke Enter dabao")

    def open_folder(self):
        try:
            os.startfile(self.mods_dir)
        except Exception:
            self.say(self.mods_dir)


# ---------------- GUI ----------------
# ---------------- Premium UI helpers ----------------
C_BG = "#0f0f14"
C_SIDE = "#14141b"
C_CARD = "#1a1a23"
C_FIELD = "#23232e"
C_ACCENT = "#4ade80"
C_ACCENT_HOVER = "#86efac"
C_TEXT = "#f2f2f7"
C_MUTED = "#8a8a9b"


class RoundButton(tk.Canvas):
    """Rounded, hover-effect wala modern button."""

    def __init__(self, parent, text, command, width=160, height=40, bg=C_ACCENT,
                 hover=C_ACCENT_HOVER, fg="#0b0b0f", parent_bg=C_CARD, radius=12,
                 font=("Segoe UI", 11, "bold")):
        super().__init__(parent, width=width, height=height, bg=parent_bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self._bw, self._bh, self._rad = width, height, radius
        self._text, self._cmd, self._font = text, command, font
        self._bg, self._hover, self._fg = bg, hover, fg
        self._state, self._over = "normal", False
        self._draw()
        self.bind("<Enter>", lambda e: self._set_over(True))
        self.bind("<Leave>", lambda e: self._set_over(False))
        self.bind("<Button-1>", self._click)

    def _set_over(self, v):
        self._over = v
        self._draw()

    def _click(self, _e):
        if self._state == "normal" and self._cmd:
            self._cmd()

    def _draw(self):
        self.delete("all")
        if self._state == "disabled":
            fill, fg = "#2a2a35", C_MUTED
        else:
            fill, fg = (self._hover if self._over else self._bg), self._fg
        w, h, r = self._bw - 1, self._bh - 1, self._rad
        pts = [r, 0, w - r, 0, w, 0, w, r, w, h - r, w, h, w - r, h, r, h,
               0, h, 0, h - r, 0, r, 0, 0]
        self.create_polygon(pts, smooth=True, fill=fill, outline=fill)
        self.create_text(self._bw / 2, self._bh / 2, text=self._text, fill=fg, font=self._font)
        self.configure(cursor="hand2" if self._state == "normal" else "arrow")

    def configure(self, cnf=None, **kw):
        redraw = False
        if "state" in kw:
            self._state = kw.pop("state")
            redraw = True
        if "text" in kw:
            self._text = kw.pop("text")
            redraw = True
        if cnf or kw:
            super().configure(cnf, **kw)
        if redraw:
            self._draw()

    config = configure


def apply_dark_styles(root):
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("TLabel", background=C_CARD, foreground=C_TEXT)
    style.configure("TButton", background=C_FIELD, foreground=C_TEXT, borderwidth=0,
                    focusthickness=0, padding=8, relief="flat")
    style.map("TButton", background=[("active", "#2e2e3b")])
    style.configure("TEntry", fieldbackground=C_FIELD, foreground=C_TEXT,
                    insertcolor=C_TEXT, bordercolor=C_FIELD, lightcolor=C_FIELD,
                    darkcolor=C_FIELD, padding=6)
    style.configure("TCombobox", fieldbackground=C_FIELD, background=C_FIELD,
                    foreground=C_TEXT, arrowcolor=C_ACCENT, bordercolor=C_FIELD,
                    lightcolor=C_FIELD, darkcolor=C_FIELD, padding=6)
    style.map("TCombobox", fieldbackground=[("readonly", C_FIELD)],
              foreground=[("readonly", C_TEXT)])
    style.configure("Prem.Horizontal.TProgressbar", troughcolor=C_FIELD,
                    background=C_ACCENT, bordercolor=C_FIELD, lightcolor=C_ACCENT,
                    darkcolor=C_ACCENT, thickness=8)
    style.configure("Vertical.TScrollbar", background=C_FIELD, troughcolor=C_BG,
                    bordercolor=C_BG, arrowcolor=C_MUTED)
    root.option_add("*TCombobox*Listbox.background", C_FIELD)
    root.option_add("*TCombobox*Listbox.foreground", C_TEXT)
    root.option_add("*TCombobox*Listbox.selectBackground", C_ACCENT)
    root.option_add("*TCombobox*Listbox.selectForeground", "#000000")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("FastLauncher")
        set_logo(self)
        self.geometry("860x580")
        self.configure(bg=C_BG)
        self.resizable(False, False)
        cfg = load_config()
        apply_dark_styles(self)

        self.name = tk.StringVar(value=cfg.get("name", "Player"))
        self.version = tk.StringVar(value=cfg.get("version", DEFAULT_VERSION))
        self.ram = tk.IntVar(value=cfg.get("ram", DEFAULT_RAM_GB))

        # ---------- Sidebar ----------
        side = tk.Frame(self, bg=C_SIDE, width=230)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        try:
            self._side_logo = tk.PhotoImage(data=LOGO_B64)
            tk.Label(side, image=self._side_logo, bg=C_SIDE).pack(pady=(34, 8))
        except Exception:
            pass
        tk.Label(side, text="FastLauncher", font=("Segoe UI", 17, "bold"),
                 bg=C_SIDE, fg=C_TEXT).pack()
        tk.Label(side, text="Low-end PC ke liye optimized", font=("Segoe UI", 9),
                 bg=C_SIDE, fg=C_MUTED).pack(pady=(2, 26))
        RoundButton(side, "MODS", self.open_mods, width=180, height=42, bg=C_FIELD,
                    hover="#2e2e3b", fg=C_TEXT, parent_bg=C_SIDE).pack(pady=4)
        tk.Label(side, text="Fabric  \u2022  Sodium  \u2022  Lithium", font=("Segoe UI", 8),
                 bg=C_SIDE, fg=C_MUTED).pack(side="bottom", pady=18)

        # ---------- Main area ----------
        main = tk.Frame(self, bg=C_BG)
        main.pack(side="left", fill="both", expand=True, padx=28, pady=24)

        tk.Label(main, text="Play", font=("Segoe UI", 24, "bold"),
                 bg=C_BG, fg=C_TEXT).pack(anchor="w")
        tk.Label(main, text="Install, mods aur game, sab ek click me",
                 font=("Segoe UI", 10), bg=C_BG, fg=C_MUTED).pack(anchor="w", pady=(0, 14))

        card = tk.Frame(main, bg=C_CARD)
        card.pack(fill="x")
        inner = tk.Frame(card, bg=C_CARD)
        inner.pack(fill="x", padx=22, pady=18)
        inner.columnconfigure(1, weight=1)

        def label(text, row):
            tk.Label(inner, text=text, font=("Segoe UI", 10), bg=C_CARD,
                     fg=C_MUTED).grid(row=row, column=0, sticky="w", pady=8, padx=(0, 18))

        label("Username", 0)
        ttk.Entry(inner, textvariable=self.name, font=("Segoe UI", 10)).grid(
            row=0, column=1, sticky="ew")
        label("Version", 1)
        ttk.Combobox(inner, textvariable=self.version, font=("Segoe UI", 10),
                     values=["1.21.11", "1.20.1", "1.20.4", "1.21.1", "1.19.4",
                             "1.18.2", "1.16.5"]).grid(row=1, column=1, sticky="ew")
        label("RAM", 2)
        ramrow = tk.Frame(inner, bg=C_CARD)
        ramrow.grid(row=2, column=1, sticky="ew")
        ramrow.columnconfigure(0, weight=1)
        self.ram_label = tk.Label(ramrow, text=f"{self.ram.get()} GB", width=6,
                                  font=("Segoe UI", 10, "bold"), bg=C_CARD, fg=C_ACCENT)
        tk.Scale(ramrow, from_=2, to=6, orient="horizontal", variable=self.ram,
                 showvalue=0, bg=C_CARD, fg=C_TEXT, troughcolor=C_FIELD,
                 activebackground=C_ACCENT, highlightthickness=0, bd=0, sliderlength=22,
                 width=12, command=lambda v: self.ram_label.configure(text=f"{int(float(v))} GB")
                 ).grid(row=0, column=0, sticky="ew")
        self.ram_label.grid(row=0, column=1, padx=(10, 0))

        playrow = tk.Frame(main, bg=C_BG)
        playrow.pack(fill="x", pady=(16, 10))
        self.btn = RoundButton(playrow, "\u25B6   PLAY", self.start, width=220, height=50,
                               parent_bg=C_BG, font=("Segoe UI", 13, "bold"), radius=14)
        self.btn.pack(side="left")
        tk.Label(playrow, text="Pehli baar game aur mods install honge",
                 font=("Segoe UI", 9), bg=C_BG, fg=C_MUTED).pack(side="left", padx=14)

        self.bar = ttk.Progressbar(main, mode="determinate",
                                   style="Prem.Horizontal.TProgressbar")
        self.bar.pack(fill="x", pady=(0, 10))

        tk.Label(main, text="Activity", font=("Segoe UI", 9, "bold"),
                 bg=C_BG, fg=C_MUTED).pack(anchor="w")
        logwrap = tk.Frame(main, bg=C_CARD)
        logwrap.pack(fill="both", expand=True, pady=(4, 0))
        self.logbox = tk.Text(logwrap, height=8, bg=C_CARD, fg="#b4b4c4", relief="flat",
                              bd=0, padx=14, pady=10, font=("Consolas", 9),
                              state="disabled", wrap="word")
        self.logbox.pack(fill="both", expand=True)

    def log(self, msg):
        def _w():
            self.logbox.configure(state="normal")
            self.logbox.insert("end", msg + "\n")
            self.logbox.see("end")
            self.logbox.configure(state="disabled")
        self.after(0, _w)

    def set_progress(self, value, maximum=None):
        def _p():
            if maximum:
                self.bar.configure(maximum=maximum)
            self.bar.configure(value=value)
        self.after(0, _p)

    def open_mods(self):
        ModsWindow(self, lambda: self.version.get().strip())

    def start(self):
        name = self.name.get().strip() or "Player"
        save_config({"name": name, "version": self.version.get(), "ram": self.ram.get()})
        self.btn.configure(state="disabled")
        threading.Thread(target=self.run_all, daemon=True).start()

    def run_all(self):
        try:
            mc = self.version.get().strip()
            name = self.name.get().strip() or "Player"
            ram = max(2, int(self.ram.get()))
            os.makedirs(MC_DIR, exist_ok=True)

            cb = {
                "setStatus": lambda t: self.log(t),
                "setMax": lambda m: self.set_progress(0, m),
                "setProgress": lambda p: self.set_progress(p),
            }
            self.log(f"Minecraft {mc} + Java install ho raha hai (pehli baar time lagega)...")
            mll.install.install_minecraft_version(mc, MC_DIR, callback=cb)

            # Minecraft ka apna Java (system Java ki zaroorat nahi)
            java_path = None
            try:
                info = mll.runtime.get_version_runtime_information(mc, MC_DIR)
                if info:
                    java_path = mll.runtime.get_executable_path(info["name"], MC_DIR)
            except Exception as e:
                self.log(f"Java path nahi mila: {e}")

            fabric_id = find_fabric_id(mc)
            if not fabric_id:
                self.log("Fabric install ho raha hai...")
                mll.fabric.install_fabric(mc, MC_DIR, callback=cb, java=java_path)
                fabric_id = find_fabric_id(mc)
            if not fabric_id:
                raise RuntimeError("Fabric install nahi hua. Version check karo.")

            self.log("Performance mods check ho rahe hain...")
            mods_dir = os.path.join(MC_DIR, "mods")
            os.makedirs(mods_dir, exist_ok=True)
            for i, slug in enumerate(MODS):
                try:
                    download_mod(slug, mc, mods_dir, self.log)
                except Exception as e:
                    self.log(f"  [error] {slug}: {e}")
                self.set_progress(i + 1, len(MODS))

            apply_low_end_options()

            options = {
                "username": name,
                "uuid": offline_uuid(name),
                "token": "0",
                "jvmArguments": [f"-Xms{ram}G", f"-Xmx{ram}G"] + JVM_FLAGS,
            }
            if java_path:
                options["executablePath"] = java_path
            else:
                self.log("Java runtime nahi mila, system Java try kar raha hoon...")
            cmd = mll.command.get_minecraft_command(fabric_id, MC_DIR, options)
            self.log("Game start ho raha hai...")
            flags = 0x08000000 if sys.platform == "win32" else 0  # no console window
            subprocess.Popen(cmd, cwd=MC_DIR, creationflags=flags)
            self.log("Done! Game window thodi der me khulegi.")
        except Exception as e:
            self.log(f"ERROR: {e}")
            self.after(0, lambda: messagebox.showerror("Error", str(e)))
        finally:
            self.after(0, lambda: self.btn.configure(state="normal"))


def relaunch_without_console():
    """python.exe se chalaya ho to pythonw.exe se dobara chalao, taaki black CMD window na rahe."""
    if sys.platform != "win32" or getattr(sys, "frozen", False):
        return
    if os.path.basename(sys.executable).lower() != "python.exe":
        return
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if not os.path.exists(pyw):
        return
    try:
        DETACHED_PROCESS, CREATE_NO_WINDOW = 0x00000008, 0x08000000
        subprocess.Popen([pyw, os.path.abspath(__file__)],
                         creationflags=DETACHED_PROCESS | CREATE_NO_WINDOW,
                         close_fds=True)
    except Exception:
        return
    sys.exit(0)


def redirect_output_to_log():
    """Console nahi hai to print/errors ek log file me jaayein (crash se bachne ke liye)."""
    if sys.stdout is None or sys.stderr is None:
        try:
            os.makedirs(APP_DIR, exist_ok=True)
            f = open(os.path.join(APP_DIR, "launcher.log"), "a", encoding="utf-8")
            sys.stdout = sys.stdout or f
            sys.stderr = sys.stderr or f
        except Exception:
            pass


if __name__ == "__main__":
    relaunch_without_console()
    redirect_output_to_log()
    set_app_id()
    try:
        App().mainloop()
    except Exception:
        import traceback
        err = traceback.format_exc()
        try:
            os.makedirs(APP_DIR, exist_ok=True)
            with open(os.path.join(APP_DIR, "launcher.log"), "a", encoding="utf-8") as f:
                f.write(err + "\n")
        except Exception:
            pass
        try:
            _r = tk.Tk()
            _r.withdraw()
            messagebox.showerror("FastLauncher error", err[-900:])
        except Exception:
            pass
