; FastLauncher installer script (Inno Setup 6)
#define AppName "FastLauncher"
#define AppVersion "1.0.0"

[Setup]
AppId={{B7C3E1A2-5D4F-4C1E-9A6B-2F8D7E3C9A10}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=FastLauncher
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir=installer
OutputBaseFilename=FastLauncher_Setup
SetupIconFile=logo.ico
UninstallDisplayIcon={app}\logo.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
; admin ki zaroorat nahi, user ke apne account me install hota hai
PrivilegesRequired=lowest

[Tasks]
Name: "desktopicon"; Description: "Desktop par shortcut banao"; GroupDescription: "Extra:"

[Files]
Source: "dist\FastLauncher.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "logo.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\FastLauncher.exe"; IconFilename: "{app}\logo.ico"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\FastLauncher.exe"; IconFilename: "{app}\logo.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\FastLauncher.exe"; Description: "FastLauncher abhi chalao"; Flags: nowait postinstall skipifsilent
