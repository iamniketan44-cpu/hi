# FastLauncher

Low-end PC ke liye optimized Minecraft launcher (Fabric + Sodium, Lithium, FerriteCore, EntityCulling, ModernFix, ImmediatelyFast, Mod Menu, Modern Keystrokes). Isme mods search/install (Modrinth), logo ke saath list, aur dark premium UI hai.

## Install karna (users ke liye)

1. Latest **`FastLauncher_Setup.exe`** download karo (GitHub ke **Releases** page se).
2. Double-click karo, **Next -> Install**. Admin permission ki zaroorat nahi.
3. Desktop ya Start Menu se **FastLauncher** kholo, username daalo aur **PLAY** dabao.

Python ya Java install karne ki zaroorat nahi. Pehli baar game files aur mods download hote hain.

> Windows "SmartScreen" warning aa sakti hai kyunki app signed nahi hai.
> **More info -> Run anyway** par click karo.

## Installer banana (developer ke liye)

### Tareeka 1: GitHub se apne aap (sabse aasaan)
1. Saari files GitHub repository me upload karo (`.github/workflows/build.yml` folder samet).
2. **Releases -> Create a new release**, tag me `v1.0.0` likho aur publish karo.
3. Kuch minute baad release me `FastLauncher_Setup.exe` apne aap aa jaati hai.
   (Ya **Actions -> Build Windows installer -> Run workflow** se bhi bana sakte ho.)

### Tareeka 2: Apne Windows PC par
1. `fast_launcher.py`, `logo.ico`, `setup.iss`, `requirements.txt` aur `build_installer.bat` ek folder me rakho.
2. Ek baar Inno Setup install karo: `winget install JRSoftware.InnoSetup`
3. `build_installer.bat` double-click karo.
4. `installer\FastLauncher_Setup.exe` ban jaayegi.

## Source se chalana

```
py -m pip install -r requirements.txt
py fast_launcher.py
```

## Note

Launcher abhi offline username mode me chalta hai (Microsoft login nahi hai).
